-- Reference copy. The application creates this automatically (StudentDAO.createTableIfNotExists).
CREATE DATABASE IF NOT EXISTS sms_db;
USE sms_db;
CREATE TABLE IF NOT EXISTS students (
    id      INT          NOT NULL PRIMARY KEY,
    name    VARCHAR(100) NOT NULL,
    age     INT          NOT NULL,
    course  VARCHAR(100) NOT NULL,
    marks   DOUBLE       NOT NULL,
    CONSTRAINT chk_age   CHECK (age > 17),
    CONSTRAINT chk_marks CHECK (marks BETWEEN 0 AND 100)
);
